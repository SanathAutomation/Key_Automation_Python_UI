import time

from selenium.webdriver.common.by import By
class LoginPageClass:
    username_Xpath = "//input[@name='username']"
    password_Xpath = "//input[@name='password']"

    signedIn_Checkbox_xpath = "//span[@class='b-checkbox b-checkbox_checked']"
    signInButton_xpath = "//div[contains(text(),'Sign In')]"


    def __init__(self,driver):
        self.driver = driver

    def provide_username(self, username):
        self.driver.find_element(By.XPATH,self.username_Xpath).send_keys(username)
        #self.driver.find_element_by_xpath(self.textbox_searchStock).send_keys(stockname)

    def provide_password(self, password):
        self.driver.find_element(By.XPATH,self.password_Xpath).send_keys(password)


    def signedInCheckbox(self):
        self.driver.find_element(By.XPATH,self.signedIn_Checkbox_xpath).click()
        time.sleep(2)

    def signInButton(self):
        self.driver.find_element(By.XPATH,self.signInButton_xpath).click()
        time.sleep(2)












