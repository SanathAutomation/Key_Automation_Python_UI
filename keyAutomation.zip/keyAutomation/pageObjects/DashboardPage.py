import time

from selenium.webdriver.common.by import By
class DashboardPageClass:
    test_Builder_Xpath = "//div[contains(text(),'Test Builder')]"
    build_BlankTestCase_Xpath = "(//button[starts-with(@class,'test-builder-modal_testBuilderItem')])[1]"
    import_TestCase_Xpath = "(//button[starts-with(@class,'test-builder-modal_testBuilderItem')])[1]"
    profile_Builder_Xpath = "//div[contains(text(),'Profile Builder')]"






    def __init__(self,driver):
        self.driver = driver

    def testBuilderAction(self):
        self.driver.find_element(By.XPATH,self.test_Builder_Xpath).click()

    def profileBuilderAction(self):
        self.driver.find_element(By.XPATH,self.profile_Builder_Xpath).click()

















