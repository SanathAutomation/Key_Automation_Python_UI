import time

from selenium.webdriver.common.by import By
class TestBuilderPageClass:
    #Quick start options
    blankTestCase_Xpath = "(//button[starts-with(@class,'test-builder-modal_testBuilder')])[1]"
    importTestCase_Xpath = "(//button[starts-with(@class,'test-builder-modal_testBuilder')])[2]"

    blankTestCaseProjectName_Xpath = "(//input[starts-with(@class,'input_input')])[2]"
    blank_TestName_Xpath = "(//input[starts-with(@class,'input_input')])[3]"
    saveBlankTestCase_Xpath = "//div[contains(text(),'Save')]"
    blankTestCaseProjectDropdown_Xpath = "//div[starts-with(@class,'editable-dropdown_menuItem__')]"
    selectFileToImport_Xpath = "//div[contains(text(),'Select File')]"
    import_TestCase_Xpath = "(//button[starts-with(@class,'test-builder-modal_testBuilderItem')])[2]"
    import_TestCase_Xpath = "(//button[starts-with(@class,'test-builder-modal_testBuilderItem')])[2]"







    def __init__(self,driver):
        self.driver = driver

    def testBuilderBlankTestFromScratch(self):
        self.driver.find_element(By.XPATH,self.blankTestCase_Xpath).click()

    def testBuilderProjectName(self,ProjectName):
        self.driver.find_element(By.XPATH,self.blankTestCaseProjectName_Xpath).send_keys(ProjectName)
        self.driver.find_element(By.XPATH, self.blankTestCaseProjectName_Xpath).click()

    def testBuilderProjectDropdown(self):
        self.driver.find_element(By.XPATH,self.blankTestCaseProjectDropdown_Xpath).click()

    def testBuilderTestName(self,TestName):
        self.driver.find_element(By.XPATH,self.blank_TestName_Xpath).send_keys(TestName)


    def testBuilderBlankTestSave(self):
        self.driver.find_element(By.XPATH,self.saveBlankTestCase_Xpath).click()

    def testBuilderImportTestFromScratch(self):
        self.driver.find_element(By.XPATH,self.importTestCase_Xpath).click()


    def selectFileToImport(self):
        self.driver.find_element(By.XPATH, self.selectFileToImport_Xpath).click()

    def UploadFileToImport(self, fileName):
        self.driver.find_element(By.XPATH,self.selectFileToImport_Xpath).send_keys(fileName)





















