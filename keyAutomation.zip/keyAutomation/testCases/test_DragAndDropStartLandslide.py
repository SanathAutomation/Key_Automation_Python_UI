import time

import pytest
from selenium import webdriver
import os

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.ProfileBuilderPage import ProfileBuilderPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from pageObjects.WorkflowPage import WorkFlowPageClass
from selenium.webdriver.common.action_chains import ActionChains
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select

# Set up Chrome options for headless mode
chrome_options = Options()
chrome_options.add_argument("--headless")  # Enable headless mode
chrome_options.add_argument("--disable-gpu")


class Test_00xxx_DragAndDropStartLandslideValidation:
    base_url = ReadConfig.getApplicationURL()
    username= ReadConfig.getusername()
    password = ReadConfig.getpassword()
    landslideServerIP = ReadConfig.getLandslideServerIP()
    landslideUsername = ReadConfig.getLandslideUsername()
    landslidePassword = ReadConfig.getLandslidePassword()


    logger = LogGen.loggen()



    def test_dragAndDropStartLandslide(self,setup):
        self.logger.info("*********Test Case 01 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        time.sleep(2)
        self.lp = LoginPageClass(self.driver)
        self.lp.provide_username(self.username)
        self.lp.provide_password(self.password)
        self.driver.maximize_window()
        self.lp.signedInCheckbox()
        self.lp.signInButton()
        self.logger.info("*********Signed In to cloudSure in AION************")
        time.sleep(2)

        act_title = self.driver.title
        # print(act_title)
        self.logger.warning("******Ttile is being verified in AION**********")
        if act_title == "Landing | AION":
            assert True
            # self.driver.close()
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
            assert False
            # self.driver.close()

        self.logger.info("*********Title is verified in login page************")
        self.landpg = LandingPageClass(self.driver)
        time.sleep(5)
        self.logger.info("**********Moved to Landing Page********")
        self.landpg.aion_products_cloudsure()
        time.sleep(2)
        self.landpg.product_instance_cloudsure()
        self.landpg.launch_product_cloudsure()
        time.sleep(20)
        self.logger.info("*****Launched product is clicked from Landing Page*****")
        print("Launched cloudsure and moved to Dashboard page")
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(10)
        print("Switched to new window")
        self.logger.info("*****New Window****")
        new_title1 = self.driver.title
        print(new_title1)
        self.dashbdpg = DashboardPageClass(self.driver)
        self.dashbdpg.profileBuilderAction()
        print("Profile Builder is clicked")
        time.sleep(2)
        self.profileBuilder = ProfileBuilderPageClass(self.driver)
        self.profileBuilder.createLoadGenAction()
        self.profileBuilder.landslide_loadGen()

        import string
        import random  # define the random module
        S = 4  # number of characters in the string.
        # call random.choices() string module to find the string in Uppercase + numeric data.
        randomLoadGen_name = "LoadGen" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
        print("The randomly generated string is : " + str(randomLoadGen_name))  # print the random data
        self.profileBuilder.environment_name(str(randomLoadGen_name))
        print("LoadGen Name is given")
        self.profileBuilder.landslide_managerServer(self.landslideServerIP)
        time.sleep(2)
        self.profileBuilder.landslide_managerUsername(self.landslideUsername)
        self.profileBuilder.landslide_managerPassword(self.landslidePassword)
        self.profileBuilder.save_button()
        print("Load Generator profile is saved")
        time.sleep(4)

        # Create Blank Test Case
        self.dashbdpg = DashboardPageClass(self.driver)
        self.dashbdpg.testBuilderAction()
        print("Test Builder is clicked")
        self.logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
        time.sleep(2)
        self.tbPage = TestBuilderPageClass(self.driver)
        self.tbPage.testBuilderBlankTestFromScratch()
        self.logger.info("*****Test bulder for Blank Test case is getting created*****")
        print("Blank Test case is ready to be created")
        self.tbPage.testBuilderProjectName("sanath_automation")
        self.tbPage.testBuilderProjectDropdown()

        # generate random string
        import string
        import random  # define the random module
        S = 10  # number of characters in the string.
        # call random.choices() string module to find the string in Uppercase + numeric data.
        testCaseranName = "TestCase" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
        print("The randomly generated string is : " + str(testCaseranName))  # print the random data

        self.tbPage.testBuilderTestName(str(testCaseranName))
        self.logger.info("***random data is feeded***")
        self.tbPage.testBuilderBlankTestSave()
        print("Moved to Workflow page")
        time.sleep(2)

        # Workflow actions
        self.wfPage = WorkFlowPageClass(self.driver)

        try:
            # Attempt to find the button element
            profile_button = self.driver.find_element(By.XPATH, "//div[contains(text(),'Profiles')]")

            # If the button is found, the assertion will pass
            assert profile_button.is_displayed(), "Button is present and displayed"
            print("Button is present on the page.")

        except NoSuchElementException:
            # If the button is not found, the assertion will fail
            print("Button is not present on the page.")

        # perform drag and drop for load gen
        lg_name = str(randomLoadGen_name)
        copied_lgname = lg_name
        print(copied_lgname)
        loadGen_Xpath = f"//div[contains(text(),'{copied_lgname}')]/../.."
        print("LG xpath is ", loadGen_Xpath)
        self.logger.info("*****Drag and drop of env starts****")
        time.sleep(10)
        # static wait to load the page
        source_LoadGen = self.driver.find_element(By.XPATH, loadGen_Xpath)
        target_LoadGen = self.driver.find_element(By.XPATH,"(//div[starts-with(@class,'drag-and-drop-util_droppable')])[2]")
        # //div[starts-with(@class,'environment-block_emptyMessage')] --> 1st
        # (//div[starts-with(@class,'droppable-module_content')])[1] --> 2nd
        # (//div[starts-with(@class,'drag-and-drop-util_droppable')])[1] --> 3rd
        # (//div[starts-with(@class,'drag-and-drop-util_droppable')])[1]/div/div --> random initially

        # target_env = self.driver.find_element(By.XPATH,"//div[contains(text(),'Drag an Environment Profile from the left panel and drop it here!')]")

        # Perform the drag-and-drop operation
        actions = ActionChains(self.driver)
        # 29 Jan --> actions.drag_and_drop(source_env, target_env).release().perform()
        # actions.click_and_hold(source_env).drag_and_drop(source_env, target_env).release().pause(20).perform()
        time.sleep(10)

        # Changes from here

        actions.click_and_hold(source_LoadGen)

        # Calculate the number of steps for a slow drag-and-drop
        steps = 10

        for _ in range(steps):
            # Calculate small offsets for each step
            offset_x = (target_LoadGen.location['x'] - source_LoadGen.location['x']) / steps
            offset_y = (target_LoadGen.location['y'] - source_LoadGen.location['y']) / steps

            # Move by offset
            actions.move_by_offset(offset_x, offset_y)

            # Add a small delay to make it slow
            actions.pause(0.1)

        # Release the mouse button to complete the drag-and-drop
        actions.release().perform()
        time.sleep(20)
        print("Created Load Gen is dragged and dropped to right hand side")

        #Scroll to Blank Scenario

        element_to_scroll = self.driver.find_element(By.XPATH,"//div[contains(text(),'Blank Scenario')]")

        # Use JavaScript to scroll to the element
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element_to_scroll)
        element_to_scroll.click()
        self.wfPage.actions_Menubar()
        #Reach to start landslide and drag and drop
        actions1 = ActionChains(self.driver)
        start_Actions = self.driver.find_element(By.XPATH, "//div[contains(text(),'Start')]")

        # Use JavaScript to scroll to the element
        self.driver.execute_script("arguments[0].scrollIntoView(true);", start_Actions)
        #start_Actions.click()


        target_BlankScenario = self.driver.find_element(By.XPATH,"//span[contains(text(),'Drag Available Actions from the left and drop them here!')]")
        self.driver.execute_script("arguments[0].scrollIntoView(true);", target_BlankScenario)
        actions1.click_and_hold(start_Actions)

        # Calculate the number of steps for a slow drag-and-drop
        # element_to_interact = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.XPATH,"//div[starts-with(@class,'scenario-content_emptyActionsContent')]")))
        # element_to_interact.click()
        stepss = 15

        for _ in range(stepss):
            # Calculate small offsets for each step
            offset_x = (target_BlankScenario.location['x'] - start_Actions.location['x']) / steps
            offset_y = (target_BlankScenario.location['y'] - start_Actions.location['y']) / steps

            # Move by offset
            actions1.move_by_offset(offset_x, offset_y)

            # Add a small delay to make it slow
            actions1.pause(0.1)

        # Release the mouse button to complete the drag-and-drop
        actions1.release().perform()
        #actions1.drag_and_drop(start_Actions, target_BlankScenario).release().perform()
        time.sleep(20)
        print("Start Landslide is dragged and dropped to right hand side")
        # Need to add from here
        basic_startLandslide = self.driver.find_element(By.XPATH,"//div[contains(text(),'Basic')]")
        self.driver.execute_script("arguments[0].scrollIntoView(true);", basic_startLandslide)
        basic_startLandslide.click()
        time.sleep(5)

        element_to_hover_over = self.driver.find_element(By.XPATH, "//*[starts-with(@class,'Styles.pillsWrapperContent')]")

        # Use ActionChains to perform the mouse hover
        action = ActionChains(self.driver)
        action.move_to_element(element_to_hover_over).perform()
        print("Start Landslide error message", element_to_hover_over.text)
        self.wfPage.libraryId_startLandslide_Dropdown()
        self.wfPage.libraryId_sms_Dropdown()
        print("SMS Dropdown selected")
        time.sleep(10)
        self.wfPage.testSessionName_Dropdown()
        self.wfPage.testSessionName_Value()
        time.sleep(10)
        print("Dropdown selected")








