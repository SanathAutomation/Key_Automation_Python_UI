import time

import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen


class Test_002_Login:
    base_url = ReadConfig.getApplicationURL()
    username= ReadConfig.getusername()
    password = ReadConfig.getpassword()


    logger = LogGen.loggen()


    def test_TestBuilder_BlankTestCaseCreation(self,setup):
        self.logger.info("*********Test Case 01 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        time.sleep(2)
        self.lp = LoginPageClass(self.driver)
        self.lp.provide_username(self.username)
        self.lp.provide_password(self.password)
        self.driver.maximize_window()
        self.lp.signedInCheckbox()
        self.lp.signInButton()
        self.logger.info("*********Signed In to cloudSure in AION************")
        time.sleep(2)

        act_title=self.driver.title
        #print(act_title)
        self.logger.warning("******Ttile is being verified in AION**********")
        if act_title == "Landing | AION" :
            assert True
            #self.driver.close()
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
            assert False
            #self.driver.close()

        self.logger.info("*********Title is verified in login page************")
        self.landpg = LandingPageClass(self.driver)
        time.sleep(5)
        self.logger.info("**********Moved to Landing Page********")
        self.landpg.aion_products_cloudsure()
        time.sleep(2)
        self.landpg.product_instance_cloudsure()
        self.landpg.launch_product_cloudsure()
        time.sleep(20)
        self.logger.info("*****Launched product is clicked from Landing Page*****")
        print("Launched cloudsure and moved to Dashboard page")
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(10)
        print("Switched to new window")
        self.logger.info("*****New Window****")
        new_title1 = self.driver.title
        print(new_title1)
        self.dashbdpg = DashboardPageClass(self.driver)
        self.dashbdpg.testBuilderAction()
        print("Test Builder is clicked")
        self.logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
        time.sleep(2)
        self.tbPage = TestBuilderPageClass(self.driver)
        self.tbPage.testBuilderBlankTestFromScratch()
        self.logger.info("*****Test bulder for Blank Test case is getting created*****")
        print("Blank Test case is ready to be created")
        self.tbPage.testBuilderProjectName("sanath_automation")
        self.tbPage.testBuilderProjectDropdown()

        #generate random string
        import string
        import random  # define the random module
        S = 10  # number of characters in the string.
        # call random.choices() string module to find the string in Uppercase + numeric data.
        ran = ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
        print("The randomly generated string is : " + str(ran))  # print the random data

        self.tbPage.testBuilderTestName(str(ran))
        self.logger.info("***random data is feeded***")
        self.tbPage.testBuilderBlankTestSave()





        #self.driver.quit()







