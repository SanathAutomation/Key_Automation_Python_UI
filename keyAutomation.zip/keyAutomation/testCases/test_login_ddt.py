import time

import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from utilities import XLUtils


class Test_002_Login_DDT:
    base_url = ReadConfig.getApplicationURL()
    path = ".//TestData/TestData.xlsx"
    logger = LogGen.loggen()


    def test_login_ddt(self,setup):
        self.logger.info("*********Test Case ddt started************")
        self.driver = setup
        self.driver.get(self.base_url)
        self.lp = LoginPageClass(self.driver)
        self.landpg = LandingPageClass(self.driver)

        self.rows = XLUtils.getRowCount(self.path,'Sheet1')
        print("Number of rows ", self.rows)

        lst_status = []

        for r in range(2,self.rows+1):
            self.username = XLUtils.readData(self.path,'Sheet1',r,1)
            self.password = XLUtils.readData(self.path, 'Sheet1', r, 2)
            self.exp = XLUtils.readData(self.path, 'Sheet1', r, 3)

            time.sleep(5)
            self.lp.provide_username(self.username)
            self.lp.provide_password(self.password)
            self.lp.signedInCheckbox()
            self.lp.signInButton()
            time.sleep(2)
            self.logger.info("*****LOGIN TO CLOUDSURE PAGE********")

            act_title = self.driver.title
            # print(act_title)
            self.logger.warning("******Title is being verified in AION**********")
            if act_title == "Landing | AION":
                assert True
                # self.driver.close()
            else:
                self.driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
                assert False

            if self.exp == "Pass" :
                self.logger.info("*****Passed****")
                lst_status.append("Pass")
                self.landpg.goto_userAccount()
                time.sleep(2)
                self.landpg.signOut_Button()

            elif self.exp == "Fail" :
                self.logger.info("*****Passed Negative Scenario***")
                lst_status.append("Pass")
                self.landpg.goto_userAccount()
                time.sleep(2)
                self.landpg.signOut_Button()

            if "Fail" not in lst_status :
                self.logger.info("*****Login DDT Passed****")
                self.driver.close()
                assert True

            else:
                self.logger.info("****Login DDT Failed***")
                self.driver.close()
                assert False

        self.logger.info("*****End of DDT login Test****")













