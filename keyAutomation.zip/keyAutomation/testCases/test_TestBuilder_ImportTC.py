import time

import pytest
from selenium import webdriver
import os
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.webdriver.common.by import By


class Test_002_Login:
    base_url = ReadConfig.getApplicationURL()
    username= ReadConfig.getusername()
    password = ReadConfig.getpassword()


    logger = LogGen.loggen()


    def test_TestBuilder_ImportTestCase(self,setup):
        self.logger.info("*********Test Case 01 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        time.sleep(2)
        self.lp = LoginPageClass(self.driver)
        self.lp.provide_username(self.username)
        self.lp.provide_password(self.password)
        self.driver.maximize_window()
        self.lp.signedInCheckbox()
        self.lp.signInButton()
        self.logger.info("*********Signed In to cloudSure in AION************")
        time.sleep(2)

        act_title=self.driver.title
        #print(act_title)
        self.logger.warning("******Ttile is being verified in AION**********")
        if act_title == "Landing | AION" :
            assert True
            #self.driver.close()
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
            assert False
            #self.driver.close()

        self.logger.info("*********Title is verified in login page************")
        self.landpg = LandingPageClass(self.driver)
        time.sleep(5)
        self.logger.info("**********Moved to Landing Page********")
        self.landpg.aion_products_cloudsure()
        time.sleep(2)
        self.landpg.product_instance_cloudsure()
        self.landpg.launch_product_cloudsure()
        time.sleep(20)
        self.logger.info("*****Launched product is clicked from Landing Page*****")
        print("Launched cloudsure and moved to Dashboard page")
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(10)
        print("Switched to new window")
        self.logger.info("*****New Window****")
        new_title1 = self.driver.title
        print(new_title1)
        self.dashbdpg = DashboardPageClass(self.driver)
        self.dashbdpg.testBuilderAction()
        print("Test Builder is clicked")
        self.logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
        time.sleep(2)
        self.tbPage = TestBuilderPageClass(self.driver)
        self.tbPage.testBuilderImportTestFromScratch()
        print("Clicked on Import Test case")
        self.tbPage.testBuilderProjectName("sanath_automation")
        time.sleep(2)
        self.tbPage.testBuilderProjectDropdown()


        #generate random string
        import string
        import random  # define the random module
        S = 10  # number of characters in the string.
        # call random.choices() string module to find the string in Uppercase + numeric data.
        randomTestNameForImport = ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
        print("The randomly generated string is : " + str(randomTestNameForImport))  # print the random data

        self.tbPage.testBuilderTestName(str(randomTestNameForImport))
        print("Random Test Name given")


        #self.tbPage.selectFileToImport()
        # Upload file
        # file_path = "C:/Users/SChakrabor/keyAutomation/TestData/StartLandslide_import.tar"
        #
        # self.tbPage.UploadFileToImport(file_path)
        # print("File uploaded")
        # self.tbPage.testBuilderBlankTestSave()
        # print("Test Saved for Import")
        time.sleep(5)

        upload_file = os.path.abspath(
            os.path.join(os.path.dirname("C:/Users/SChakrabor/keyAutomation/TestData/"), "", "StartLandslide_import.tar"))

        file_input = self.driver.find_element(By.CSS_SELECTOR, "input[type='file']")
        file_input.send_keys(upload_file)
        time.sleep(5)
        print("File Uploaded to import test")

        self.tbPage.testBuilderBlankTestSave()
        print("Test Saved for Import")
        #assert self.driver.find_element(By.XPATH,"//div[contains(text(),'Profiles')]").is_displayed(), "Profiles"
        #// div[contains(text(), 'Profiles')]










        #self.driver.quit()







