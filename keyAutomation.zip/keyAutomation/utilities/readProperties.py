import configparser

config = configparser.RawConfigParser()
config.read(".\\Configurations\\config.ini")

class ReadConfig:
    @staticmethod
    def getApplicationURL():
        url = config.get('common info','base_url')
        return url

    @staticmethod
    def getusername():
        username = config.get('common info', 'user_name')
        return username

    @staticmethod
    def getpassword():
        password = config.get('common info', 'pass_word')
        return password

    @staticmethod
    def getLandslideServerIP():
        serverIP = config.get('common info', 'landslide_managerServerIP1')
        return serverIP

    @staticmethod
    def getLandslideUsername():
        landslideUsername = config.get('common info', 'landslide_managerUserName')
        return landslideUsername

    @staticmethod
    def getLandslidePassword():
        landslidePassword = config.get('common info', 'landslide_managerPassword')
        return landslidePassword


